/**
 * VOLT Common Utilities, Header, Footer & Chatbot Component
 */

(function () {
    // 1. Setup Chatbot UI and Logic
    function initChatbot() {
        if (document.getElementById('volt-chatbot-container')) return;

        const container = document.createElement('div');
        container.id = 'volt-chatbot-container';
        container.innerHTML = `
            <style>
                .chatbot-btn { position: fixed; bottom: 20px; right: 20px; background: #ff4747; color: #fff; border: none; border-radius: 50%; width: 60px; height: 60px; font-size: 24px; cursor: pointer; box-shadow: 0 4px 15px rgba(255, 71, 71, 0.4); z-index: 99999; transition: transform 0.3s; display: flex; align-items: center; justify-content: center; }
                .chatbot-btn:hover { transform: scale(1.1); }
                .chat-window { position: fixed; bottom: 90px; right: 20px; width: 340px; max-width: calc(100vw - 40px); background: #1c1c1c; border-radius: 12px; border: 1px solid #333; box-shadow: 0 8px 30px rgba(0,0,0,0.6); display: none; flex-direction: column; overflow: hidden; z-index: 99999; }
                .chat-header { background: #222; padding: 15px; border-bottom: 1px solid #333; display: flex; justify-content: space-between; align-items: center; color: #fff; font-weight: bold; }
                .close-chat { cursor: pointer; color: #ff4747; font-size: 18px; font-weight: bold; }
                .chat-body { padding: 15px; height: 320px; overflow-y: auto; display: flex; flex-direction: column; gap: 12px; background: #121212; }
                .message { max-width: 85%; padding: 10px 14px; border-radius: 15px; font-size: 13.5px; line-height: 1.45; word-wrap: break-word; }
                .user-msg { background: #ff4747; color: #fff; align-self: flex-end; border-bottom-right-radius: 2px; }
                .bot-msg { background: #24252e; color: #e2e8f0; align-self: flex-start; border-bottom-left-radius: 2px; border: 1px solid #333; }
                .chat-footer { padding: 10px; background: #222; border-top: 1px solid #333; display: flex; gap: 8px; }
                .chat-input { flex: 1; padding: 10px 14px; border: 1px solid #444; border-radius: 20px; background: #121212; color: #fff; outline: none; font-size: 13px; }
                .send-btn { background: #ff4747; border: none; color: #fff; border-radius: 50%; width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: 0.2s; font-size: 15px; }
                .send-btn:hover { background: #e03e3e; }
            </style>
            <button class="chatbot-btn" id="toggleChatBtn" title="Chat with Volt AI">💬</button>
            <div class="chat-window" id="chatWindow">
                <div class="chat-header">
                    <span>⚡ Volt AI Assistant</span>
                    <span class="close-chat" id="closeChatBtn">✕</span>
                </div>
                <div class="chat-body" id="chatBody">
                    <div class="message bot-msg">Hi! I am Volt AI. ⚡ How can I assist you with our audio gear and smartwatches today?</div>
                </div>
                <div class="chat-footer">
                    <input type="text" id="chatInput" class="chat-input" placeholder="Ask about watches, earbuds...">
                    <button class="send-btn" id="sendChatBtn">➤</button>
                </div>
            </div>
        `;
        document.body.appendChild(container);

        const toggleBtn = document.getElementById('toggleChatBtn');
        const closeBtn = document.getElementById('closeChatBtn');
        const chatWindow = document.getElementById('chatWindow');
        const inputField = document.getElementById('chatInput');
        const sendBtn = document.getElementById('sendChatBtn');
        const chatBody = document.getElementById('chatBody');

        function toggleChat() {
            chatWindow.style.display = (chatWindow.style.display === 'flex') ? 'none' : 'flex';
            if (chatWindow.style.display === 'flex') {
                inputField.focus();
            }
        }

        toggleBtn.addEventListener('click', toggleChat);
        closeBtn.addEventListener('click', toggleChat);

        function sendMsg() {
            const text = inputField.value.trim();
            if (!text) return;

            appendMsg(text, 'user-msg');
            inputField.value = '';

            setTimeout(() => {
                const reply = window.VoltDB ? window.VoltDB.chatbotReply(text) : "Welcome to Volt!";
                appendMsg(reply, 'bot-msg');
            }, 450);
        }

        function appendMsg(html, className) {
            const div = document.createElement('div');
            div.className = 'message ' + className;
            div.innerHTML = html;
            chatBody.appendChild(div);
            chatBody.scrollTop = chatBody.scrollHeight;
        }

        sendBtn.addEventListener('click', sendMsg);
        inputField.addEventListener('keypress', function (e) {
            if (e.key === 'Enter') sendMsg();
        });
    }

    // 2. Setup Header User Status (Login / Logout)
    function setupUserStatus() {
        const userStatusContainer = document.getElementById('user-status-slot');
        if (!userStatusContainer) return;

        const user = window.VoltDB ? window.VoltDB.getCurrentUser() : null;
        if (user) {
            userStatusContainer.innerHTML = `
                <a href="#" id="logoutBtn" class="btn" style="margin-right: 10px; background: #333; color: #fff;">Logout (${user.username})</a>
            `;
            const logoutBtn = document.getElementById('logoutBtn');
            if (logoutBtn) {
                logoutBtn.addEventListener('click', function (e) {
                    e.preventDefault();
                    window.VoltDB.logoutUser();
                    window.location.reload();
                });
            }
        } else {
            userStatusContainer.innerHTML = `
                <a href="login.html" class="btn" style="margin-right: 10px; background: #ff4747; color: #fff;">👤 User Login</a>
            `;
        }
    }

    // 3. Search Form Listener
    function setupSearch() {
        const searchForms = document.querySelectorAll('.volt-search-form');
        searchForms.forEach(form => {
            form.addEventListener('submit', function (e) {
                e.preventDefault();
                const input = form.querySelector('input[name="search"]');
                const q = input ? encodeURIComponent(input.value.trim()) : '';
                window.location.href = `index.html?search=${q}`;
            });
        });
    }

    document.addEventListener('DOMContentLoaded', function () {
        initChatbot();
        setupUserStatus();
        setupSearch();
        if (window.VoltDB) {
            window.VoltDB.updateCartBadge();
        }
    });
})();
