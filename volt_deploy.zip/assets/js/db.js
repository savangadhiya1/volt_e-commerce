/**
 * VOLT Client-Side Database & State Management System
 * Enables 100% serverless, zero-MySQL operation for portfolios, mobile devices, and static hosting (GitHub Pages, Vercel, Netlify)
 */

(function () {
    const STORAGE_KEY = 'volt_database_v1';
    const SESSION_USER_KEY = 'volt_current_user';
    const SESSION_ADMIN_KEY = 'volt_admin_logged_in';
    const CART_KEY = 'volt_cart';
    const DISCOUNT_KEY = 'volt_discount';

    // Default Seed Data extracted directly from MySQL volt_shop database
    const DEFAULT_DATA = {
        offer_bar: "⚡ FLASH SALE: Premium Volt Audio gear up to 60% off! ⚡",
        categories: [
            { id: 1, name: "Smartwatches" },
            { id: 2, name: "Headphones" },
            { id: 3, name: "Wireless Neckbands" },
            { id: 4, name: "Wireless Earbuds" },
            { id: 5, name: "Speakers" }
        ],
        products: [
            {
                id: 1,
                name: "Volt Rockerz Futuristic Edition",
                description: "Next-gen over-ear headphones featuring carbon fiber composite drivers, adaptive ANC, and up to 40 hours of playback.",
                price: 2499.00,
                original_price: 4999.00,
                discount: "50% off",
                image: "volt-headphone-futuristic.png",
                category_id: 2,
                rating: 4.9,
                reviews: 142
            },
            {
                id: 2,
                name: "Volt Sonic Boom 5",
                description: "Flagship premium speaker featuring an illuminated AMOLED micro-casing display and medical-grade heart metrics.",
                price: 3299.00,
                original_price: 7999.00,
                discount: "58% off",
                image: "Volt Sonic Boom 5.png",
                category_id: 5,
                rating: 4.8,
                reviews: 96
            },
            {
                id: 3,
                name: "The VOLT BassBuds",
                description: "Highly ergonomic wireless neckband utilizing dynamic graphene audio soundstages and flexible lightweight structural bands.",
                price: 1799.00,
                original_price: 3999.00,
                discount: "55% off",
                image: "The VOLT BassBuds.png",
                category_id: 3,
                rating: 4.7,
                reviews: 210
            },
            {
                id: 4,
                name: "The VOLT FitWatch X1",
                description: "Ultra-sleek fitness smartwatch with vivid AMOLED display, continuous heart rate, SpO2 sensor, and 10-day battery life.",
                price: 2222.00,
                original_price: 4443.99,
                discount: "50% off",
                image: "The VOLT FitWatch X1.png",
                category_id: 1,
                rating: 4.6,
                reviews: 84
            },
            {
                id: 5,
                name: "Volt Pods E1",
                description: "Compact wireless earbuds with punchy bass, ENC clear calling mics, instant pairing, and IPX5 sweat resistance.",
                price: 1199.95,
                original_price: 2298.98,
                discount: "50% off",
                image: "Volt Pods E1.png",
                category_id: 4,
                rating: 4.5,
                reviews: 73
            },
            {
                id: 6,
                name: "Volt Sonic Over-Ear Headphones",
                description: "Active Noise Cancellation (ANC), 40-hour battery life, Deep Bass Drivers, Lightweight Comfort Design, Bluetooth 5.2.",
                price: 5999.00,
                original_price: 9999.00,
                discount: "40% off",
                image: "Volt Sonic (V-HP01).png",
                category_id: 2,
                rating: 4.8,
                reviews: 58
            },
            {
                id: 7,
                name: "Volt Pulse Smartwatch",
                description: "1.4\" HD Retina Display, Heart Rate & SpO2 Monitor, 5ATM Water Resistance, Built-in GPS, Multi-Sport Tracking.",
                price: 2499.00,
                original_price: 4999.00,
                discount: "50% off",
                image: "Volt Pulse (V-SW05).png",
                category_id: 1,
                rating: 4.6,
                reviews: 64
            },
            {
                id: 8,
                name: "Volt Flex Neckband Earphones",
                description: "Flex-Form Cable, Magnetic Earbuds, 25-hour Playtime, Environmental Noise Cancellation (ENC), Quick Charge (10 mins = 5 hours).",
                price: 2499.00,
                original_price: 4998.98,
                discount: "50% off",
                image: "Volt Flex (V-NB20).png",
                category_id: 3,
                rating: 4.5,
                reviews: 42
            },
            {
                id: 9,
                name: "Volt Blast Portable Speaker",
                description: "20W Deep Bass, 360-degree Stereo Sound, 12-Hour Battery, IPX7 Waterproof, Bluetooth 5.0 with TWS Pairing.",
                price: 2999.00,
                original_price: 4999.00,
                discount: "40% off",
                image: "Volt Blast (V-PK30).png",
                category_id: 5,
                rating: 4.7,
                reviews: 89
            },
            {
                id: 10,
                name: "Volt Budz TWS Earbuds",
                description: "Touch Controls, Dual Mics for Clear Calls, Low Latency Gaming Mode, 30-Hour Total Playback with Type-C Fast Charging.",
                price: 1199.00,
                original_price: 2999.00,
                discount: "60% off",
                image: "Volt Budz (V-TW40).png",
                category_id: 4,
                rating: 4.4,
                reviews: 51
            },
            {
                id: 11,
                name: "Volt Arc Over-Ear Headphones",
                description: "Studio-grade acoustics with high-res audio certification, memory foam ear cups, and multi-device connection.",
                price: 4499.00,
                original_price: 7999.00,
                discount: "44% off",
                image: "VOLT 'ARC' Over-Ear.png",
                category_id: 2,
                rating: 4.9,
                reviews: 112
            },
            {
                id: 12,
                name: "Volt Flux Wireless Neckband",
                description: "Dual dynamic drivers, aerospace titanium neck wire, IPX6 waterproof rating, and 30 hours playback.",
                price: 1599.00,
                original_price: 3499.00,
                discount: "54% off",
                image: "VOLT 'FLUX' Neckband.png",
                category_id: 3,
                rating: 4.6,
                reviews: 77
            },
            {
                id: 13,
                name: "Volt Prisma Portable Speaker",
                description: "RGB light ring with sound sync, punchy neodymium drivers, 16 hours endurance, and rugged carabiner clip.",
                price: 2799.00,
                original_price: 5499.00,
                discount: "49% off",
                image: "VOLT 'PRISMA' Portable Speaker.png",
                category_id: 5,
                rating: 4.8,
                reviews: 95
            },
            {
                id: 14,
                name: "Volt Quantum Smartwatch",
                description: "Corning Gorilla Glass curved display, Bluetooth calling with high-clarity speaker, titanium bezel, and AI voice assistant.",
                price: 3999.00,
                original_price: 7999.00,
                discount: "50% off",
                image: "VOLT 'QUANTUM'.png",
                category_id: 1,
                rating: 4.7,
                reviews: 128
            },
            {
                id: 15,
                name: "Volt Zenith TWS Earbuds",
                description: "Hybrid active noise cancellation, transparency mode, wireless Qi charging case, and immersive spatial 3D audio.",
                price: 2199.00,
                original_price: 4499.00,
                discount: "51% off",
                image: "VOLT 'ZENITH' TWS Earbuds.png",
                category_id: 4,
                rating: 4.8,
                reviews: 165
            }
        ],
        users: [
            { id: 1, username: "jay", email: "jay1@gmail.com", password: "123", created_at: "2026-07-31" },
            { id: 2, username: "savan", email: "savan1@gmail.com", password: "123", created_at: "2026-08-21" },
            { id: 3, username: "meet", email: "meet1@gmail.com", password: "123", created_at: "2026-08-21" }
        ],
        admins: [
            { id: 4, username: "admin", password: "123" }
        ],
        reviews: [
            { id: 1, product_id: 1, user_name: "jay", rating: 5, review_text: "Incredible bass response and the ANC works like magic on flights!", created_at: "2026-08-01" },
            { id: 2, product_id: 2, user_name: "savan", rating: 5, review_text: "Top-notch speaker build. Fills the whole room with crisp sound.", created_at: "2026-08-21" },
            { id: 3, product_id: 3, user_name: "meet", rating: 5, review_text: "Very comfortable neckband for long workouts, battery lasts forever.", created_at: "2026-09-02" },
            { id: 4, product_id: 14, user_name: "jay", rating: 5, review_text: "The Bluetooth call quality and display resolution are impressive.", created_at: "2026-10-10" }
        ],
        orders: [
            { id: 1, user_id: 1, total_amount: 2222.00, order_date: "2026-07-31", items: [{ product_id: 4, quantity: 1, price: 2222.00, name: "The VOLT FitWatch X1", image: "The VOLT FitWatch X1.png" }] },
            { id: 2, user_id: 1, total_amount: 3299.00, order_date: "2026-08-01", items: [{ product_id: 2, quantity: 1, price: 3299.00, name: "Volt Sonic Boom 5", image: "Volt Sonic Boom 5.png" }] },
            { id: 3, user_id: 2, total_amount: 2499.00, order_date: "2026-08-21", items: [{ product_id: 1, quantity: 1, price: 2499.00, name: "Volt Rockerz Futuristic Edition", image: "volt-headphone-futuristic.png" }] },
            { id: 4, user_id: 3, total_amount: 1799.00, order_date: "2026-08-21", items: [{ product_id: 3, quantity: 1, price: 1799.00, name: "The VOLT BassBuds", image: "The VOLT BassBuds.png" }] }
        ]
    };

    // Load or initialize localStorage database
    function getDb() {
        try {
            const raw = localStorage.getItem(STORAGE_KEY);
            if (!raw) {
                localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_DATA));
                return JSON.parse(JSON.stringify(DEFAULT_DATA));
            }
            return JSON.parse(raw);
        } catch (e) {
            console.warn("Storage access failed, using memory DB", e);
            return DEFAULT_DATA;
        }
    }

    function saveDb(data) {
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
        } catch (e) {
            console.error("Failed to save to localStorage", e);
        }
    }

    // Public API for VOLT
    window.VoltDB = {
        // Offer Bar
        getOfferText: function () {
            const db = getDb();
            return db.offer_bar || "⚡ FLASH SALE: Premium Volt Audio gear up to 60% off! ⚡";
        },

        // Categories
        getCategories: function () {
            const db = getDb();
            return db.categories || [];
        },

        // Products
        getProducts: function (categoryId, search) {
            const db = getDb();
            let prods = db.products || [];

            if (categoryId && parseInt(categoryId) > 0) {
                const catId = parseInt(categoryId);
                prods = prods.filter(p => parseInt(p.category_id) === catId);
            }

            if (search && search.trim() !== '') {
                const q = search.toLowerCase().trim();
                prods = prods.filter(p =>
                    (p.name && p.name.toLowerCase().includes(q)) ||
                    (p.description && p.description.toLowerCase().includes(q))
                );
            }

            // Calculate live sold count and average ratings for each product
            const allOrders = db.orders || [];
            const allReviews = db.reviews || [];

            return prods.map(p => {
                let soldCount = 0;
                allOrders.forEach(o => {
                    if (o.items) {
                        o.items.forEach(it => {
                            if (parseInt(it.product_id) === parseInt(p.id)) {
                                soldCount += (it.quantity || 1);
                            }
                        });
                    }
                });

                const prodReviews = allReviews.filter(r => parseInt(r.product_id) === parseInt(p.id));
                let avg = p.rating || 4.5;
                if (prodReviews.length > 0) {
                    const sum = prodReviews.reduce((acc, r) => acc + parseFloat(r.rating || 5), 0);
                    avg = (sum / prodReviews.length).toFixed(1);
                }

                return {
                    ...p,
                    total_sold: Math.max(soldCount, 12 + (p.id * 7)), // realistic sales metric
                    avg_rating: avg,
                    review_count: prodReviews.length + (p.reviews || 0)
                };
            });
        },

        getProductById: function (id) {
            const prods = this.getProducts(0, '');
            return prods.find(p => parseInt(p.id) === parseInt(id)) || null;
        },

        addProduct: function (newProd) {
            const db = getDb();
            const nextId = db.products.reduce((max, p) => Math.max(max, parseInt(p.id) || 0), 0) + 1;
            const product = {
                id: nextId,
                name: newProd.name || "Volt Audio Hardware",
                description: newProd.description || "",
                price: parseFloat(newProd.price) || 999,
                original_price: parseFloat(newProd.original_price) || (parseFloat(newProd.price) * 1.5),
                discount: newProd.discount || "40% off",
                image: newProd.image || "volt-headphone-futuristic.png",
                category_id: parseInt(newProd.category_id) || 1,
                rating: 4.8,
                reviews: 1,
                created_at: new Date().toISOString().slice(0, 10)
            };
            db.products.unshift(product);
            saveDb(db);
            return product;
        },

        updateProduct: function (id, updatedFields) {
            const db = getDb();
            const index = db.products.findIndex(p => parseInt(p.id) === parseInt(id));
            if (index !== -1) {
                db.products[index] = { ...db.products[index], ...updatedFields };
                saveDb(db);
                return db.products[index];
            }
            return null;
        },

        deleteProduct: function (id) {
            const db = getDb();
            db.products = db.products.filter(p => parseInt(p.id) !== parseInt(id));
            saveDb(db);
            return true;
        },

        // Reviews
        getReviews: function (productId) {
            const db = getDb();
            return (db.reviews || []).filter(r => parseInt(r.product_id) === parseInt(productId));
        },

        addReview: function (productId, rating, reviewText) {
            const db = getDb();
            const user = this.getCurrentUser();
            const userName = user ? user.username : 'Verified Customer';
            const newRev = {
                id: (db.reviews || []).length + 1,
                product_id: parseInt(productId),
                user_name: userName,
                rating: parseInt(rating),
                review_text: reviewText || '',
                created_at: new Date().toISOString().slice(0, 10)
            };
            db.reviews = db.reviews || [];
            db.reviews.unshift(newRev);
            saveDb(db);
            return newRev;
        },

        // Cart State Management
        getCart: function () {
            try {
                const raw = localStorage.getItem(CART_KEY);
                return raw ? JSON.parse(raw) : [];
            } catch (e) {
                return [];
            }
        },

        saveCart: function (cart) {
            try {
                localStorage.setItem(CART_KEY, JSON.stringify(cart));
            } catch (e) { }
            this.updateCartBadge();
        },

        addToCart: function (productId, quantity = 1) {
            const cart = this.getCart();
            const pid = parseInt(productId);
            const existing = cart.find(item => item.id === pid);

            if (existing) {
                existing.quantity += quantity;
            } else {
                cart.push({ id: pid, quantity: quantity });
            }

            this.saveCart(cart);
            return cart;
        },

        updateCartQty: function (productId, quantity) {
            let cart = this.getCart();
            const pid = parseInt(productId);
            const qty = parseInt(quantity);

            if (qty <= 0) {
                cart = cart.filter(it => it.id !== pid);
            } else {
                const item = cart.find(it => it.id === pid);
                if (item) item.quantity = qty;
            }

            this.saveCart(cart);
            return cart;
        },

        removeFromCart: function (productId) {
            let cart = this.getCart();
            const pid = parseInt(productId);
            cart = cart.filter(it => it.id !== pid);
            this.saveCart(cart);
            return cart;
        },

        clearCart: function () {
            this.saveCart([]);
            localStorage.removeItem(DISCOUNT_KEY);
        },

        getCartCount: function () {
            const cart = this.getCart();
            return cart.reduce((total, item) => total + (item.quantity || 1), 0);
        },

        updateCartBadge: function () {
            const count = this.getCartCount();
            const badges = document.querySelectorAll('.cart-count-badge');
            badges.forEach(badge => {
                if (count > 0) {
                    badge.textContent = count;
                    badge.style.display = 'inline-block';
                } else {
                    badge.style.display = 'none';
                }
            });
        },

        // Cart Calculation & Coupons
        getDiscountPct: function () {
            try {
                const d = localStorage.getItem(DISCOUNT_KEY);
                return d ? parseInt(d) : 0;
            } catch (e) {
                return 0;
            }
        },

        applyCoupon: function (code) {
            const cleanCode = (code || '').trim().toUpperCase();
            if (cleanCode === 'VOLT20') {
                localStorage.setItem(DISCOUNT_KEY, '20');
                return { success: true, discount: 20, msg: "🎉 20% Discount added." };
            } else if (cleanCode === 'VOLT50') {
                localStorage.setItem(DISCOUNT_KEY, '50');
                return { success: true, discount: 50, msg: "⚡ Flash Sale 50% Discount added." };
            } else if (cleanCode === 'FREEVOLT') {
                localStorage.setItem(DISCOUNT_KEY, '30');
                return { success: true, discount: 30, msg: "🎁 Mystery Box 30% VIP Discount unlocked!" };
            } else {
                localStorage.setItem(DISCOUNT_KEY, '0');
                return { success: false, discount: 0, msg: "❌ Invalid coupon code." };
            }
        },

        getCartDetails: function () {
            const cart = this.getCart();
            const discountPct = this.getDiscountPct();
            let subtotal = 0;
            const items = [];

            cart.forEach(c => {
                const prod = this.getProductById(c.id);
                if (prod) {
                    const price = parseFloat(prod.price) || 0;
                    const itemTotal = price * c.quantity;
                    subtotal += itemTotal;
                    items.push({
                        id: prod.id,
                        name: prod.name,
                        price: price,
                        image: prod.image,
                        quantity: c.quantity,
                        itemTotal: itemTotal
                    });
                }
            });

            const discountAmount = Math.round((subtotal * discountPct) / 100);
            const total = Math.max(0, subtotal - discountAmount);

            return {
                items: items,
                subtotal: subtotal,
                discountPct: discountPct,
                discountAmount: discountAmount,
                total: total
            };
        },

        // Checkout & Orders
        checkout: function () {
            const cartDetails = this.getCartDetails();
            if (cartDetails.items.length === 0) {
                return { success: false, msg: "Cart is empty" };
            }

            const user = this.getCurrentUser();
            const db = getDb();
            const newOrderId = (db.orders || []).length + 1;

            const order = {
                id: newOrderId,
                user_id: user ? user.id : 1,
                total_amount: cartDetails.total,
                order_date: new Date().toISOString().slice(0, 10),
                items: cartDetails.items.map(it => ({
                    product_id: it.id,
                    name: it.name,
                    price: it.price,
                    quantity: it.quantity,
                    image: it.image
                }))
            };

            db.orders = db.orders || [];
            db.orders.unshift(order);
            saveDb(db);
            this.clearCart();

            return { success: true, orderId: newOrderId, total: cartDetails.total };
        },

        getOrderHistory: function () {
            const db = getDb();
            const user = this.getCurrentUser();
            const allOrders = db.orders || [];

            if (!user) {
                // If not logged in, return default orders for demo
                return allOrders.filter(o => o.user_id === 1);
            }
            return allOrders.filter(o => parseInt(o.user_id) === parseInt(user.id));
        },

        getAllOrders: function () {
            const db = getDb();
            return db.orders || [];
        },

        // User Auth
        getCurrentUser: function () {
            try {
                const raw = localStorage.getItem(SESSION_USER_KEY);
                return raw ? JSON.parse(raw) : null;
            } catch (e) {
                return null;
            }
        },

        loginUser: function (email, password) {
            const db = getDb();
            const user = (db.users || []).find(u => u.email.toLowerCase() === email.toLowerCase());
            if (user) {
                // In demo client mode, allow standard login or password matching
                localStorage.setItem(SESSION_USER_KEY, JSON.stringify({
                    id: user.id,
                    username: user.username,
                    email: user.email
                }));
                return { success: true, user: user };
            }
            return { success: false, msg: "Invalid email or user not found." };
        },

        registerUser: function (username, email, password) {
            const db = getDb();
            const existing = (db.users || []).find(u => u.email.toLowerCase() === email.toLowerCase());
            if (existing) {
                return { success: false, msg: "Email already exists! Please login." };
            }

            const newUser = {
                id: (db.users || []).length + 1,
                username: username.trim(),
                email: email.trim(),
                password: password,
                created_at: new Date().toISOString().slice(0, 10)
            };

            db.users.push(newUser);
            saveDb(db);

            localStorage.setItem(SESSION_USER_KEY, JSON.stringify({
                id: newUser.id,
                username: newUser.username,
                email: newUser.email
            }));

            return { success: true, user: newUser };
        },

        logoutUser: function () {
            localStorage.removeItem(SESSION_USER_KEY);
        },

        getUsers: function () {
            const db = getDb();
            return db.users || [];
        },

        // Admin Auth & Portal
        isAdminLoggedIn: function () {
            return localStorage.getItem(SESSION_ADMIN_KEY) === 'true';
        },

        loginAdmin: function (username, password) {
            if (username === 'admin' && (password === '123' || password === 'admin')) {
                localStorage.setItem(SESSION_ADMIN_KEY, 'true');
                return { success: true };
            }
            return { success: false, msg: "Incorrect username or password. Default is admin / 123" };
        },

        logoutAdmin: function () {
            localStorage.removeItem(SESSION_ADMIN_KEY);
        },

        // Admin KPIs
        getKPIs: function () {
            const db = getDb();
            const prods = db.products || [];
            const users = db.users || [];
            const orders = db.orders || [];
            const totalRevenue = orders.reduce((sum, o) => sum + parseFloat(o.total_amount || 0), 0);

            return {
                total_products: prods.length,
                total_users: users.length,
                total_orders: orders.length,
                total_revenue: totalRevenue
            };
        },

        // Chatbot Client Engine
        chatbotReply: function (rawMessage) {
            const msg = (rawMessage || '').toLowerCase().trim();
            const db = getDb();

            if (!msg) {
                return "Hi there! I am Volt AI. How can I assist you with our audio and smart gear today?";
            }

            if (/\b(hi|hello|hey|help|namaste|kem cho)\b/.test(msg)) {
                return "Hello! Welcome to ⚡ <strong>VOLT</strong>. How can I upgrade your tech setup today?";
            }

            if (/\b(shipping|delivery|time|courier|dispatch)\b/.test(msg)) {
                return "🚚 We offer <strong>FREE Express Shipping</strong> across all states! Orders arrive within <strong>2 to 4 business days</strong>.";
            }

            if (/\b(return|refund|warranty|guarantee|replacement)\b/.test(msg)) {
                return "🛡️ All Volt devices come with an official <strong>1-Year Warranty</strong> and a <strong>7-day hassle-free replacement policy</strong>.";
            }

            if (/\b(coupon|discount|offer|promo|code)\b/.test(msg)) {
                return "🎉 You can use coupon <strong>VOLT20</strong> for 20% off, or visit our <a href='gifting_store.html' style='color:#ff4747;font-weight:bold;'>Gifting Store</a> to unlock secret code <strong>FREEVOLT</strong>!";
            }

            // Keyword match across products
            const matchingProd = (db.products || []).find(p =>
                p.name.toLowerCase().includes(msg) ||
                (p.description && p.description.toLowerCase().includes(msg))
            );

            if (matchingProd) {
                return `⚡ Excellent choice! Check out the <strong>${matchingProd.name}</strong> for just <strong>₹${Number(matchingProd.price).toLocaleString()}</strong> (${matchingProd.discount}). <a href="product_detail.html?id=${matchingProd.id}" style="color:#ff4747;font-weight:bold;">View Details</a>.`;
            }

            if (msg.includes('watch')) {
                return "⌚ Looking for smartwatches? Check out the <strong>Volt Quantum</strong> (AMOLED & BT Calling) or <strong>The VOLT FitWatch X1</strong>! Use category filters to explore.";
            }

            if (msg.includes('headphone') || msg.includes('earbud') || msg.includes('audio') || msg.includes('bass')) {
                return "🎧 Our <strong>Volt Rockerz Futuristic Edition</strong> and <strong>Volt Zenith ANC Earbuds</strong> deliver studio-level acoustics with deep sub-bass. Browse the storefront to explore!";
            }

            if (msg.includes('speaker')) {
                return "🔊 Need big party sound? The <strong>Volt Sonic Boom 5</strong> and <strong>Volt Blast</strong> deliver 360° booming audio!";
            }

            return "I'm still learning! ⚡ You can ask me about our <em>'headphones'</em>, <em>'smartwatches'</em>, <em>'discounts'</em>, or <em>'shipping'</em>.";
        }
    };

    // Auto-update cart badge on DOM ready
    document.addEventListener('DOMContentLoaded', function () {
        window.VoltDB.updateCartBadge();
    });
})();
